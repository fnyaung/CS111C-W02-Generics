package Lab_A_HW;

/**
 * @author Faustina Nyaung
 * Date: January 30, 2017
 * 
 * Directions:
 * Create a Java class using generics: Trio.
 * 
 * • Objects of this class hold three unordered items of the same type.
 * • A Trio object is unordered.
 * • For example, the Trio (3, 4, 5) is considered the same as the Trio (4, 5, 3) and the Trio ("hi", "bye", "hello") is considered the same as the Trio ("hello", "hi", "bye").
 * • The order doesn't matter. (This is like a set in mathematics.)
 * • Use generics to ensure that the three objects are of the same type. 
 * • For example, a Trio can hold three Integers or it could hold three Strings or it could hold three Students, etc.
 * • A Trio could not, however, hold two Integers and a String.
 * • Write this class using generics. Here is the class header: public class Trio<T> 
 */
import java.util.*;

public class Trio<T extends Comparable<? super T>> implements Comparable<Trio <T>> {

	ArrayList<T> trioList = new ArrayList<T>();
	
	//a constructor to create the object by sending three items as parameters
	public Trio(T item1, T item2, T item3){
		trioList.add(item1);
		trioList.add(item2);
		trioList.add(item3);
	}

	//getters and setter for each item in the trio
	public T getItem1() {
		return trioList.get(0);
	}

	public void setItem1(T item1) {
		trioList.set(0, item1);
	}

	public T getItem2() {
		return trioList.get(1);
	}

	public void setItem2(T item2) {
		trioList.set(1, item2);
	}

	public T getItem3() {
		return trioList.get(2);
	}

	public void setItem3(T item3) {
		trioList.set(2, item3);
	}

	public ArrayList<T> getList(){
		return trioList;
	}
	
	//returns a text representation of the trio
	@Override
	public String toString(){
		return "Item 1 is " + trioList.get(0) + "\nItem 2 is " + trioList.get(1) 
		       + "\nItem 3 is " + trioList.get(2);
	}
	
	//returns whether or not the trio contains an item sent in as a parameter
	public boolean contains(T item){
		if((trioList.get(0).equals(item)) || (trioList.get(1).equals(item)) || (trioList.get(2).equals(item))){
			return true;
		}else{
			return false;
		}
	}
		
	//returns true if the three items are the same as each other
	public boolean sameItems(){
		if((trioList.get(0).equals(trioList.get(1)) && (trioList.get(1).equals(trioList.get(2))))){
			return true;
		}else{
			return false;
		}
	}
	
	/*************************************************************************
	 * The method returns true if the current Trio holds the same three items
	 * in any order as the Trio sent as a parameter and false otherwise.
	 *************************************************************************/
	@Override
	public boolean equals(Object other){

		if(other instanceof Trio<?>){
			Trio<?> otherTrio = (Trio<?>) other;
			ArrayList<T> otherTrioList = (ArrayList<T>) otherTrio.getList();

			if(trioList.equals(otherTrioList)){
				return true;
			}else if(((trioList.get(1)).equals((otherTrioList.get(0)))) &&
					   ((trioList.get(2)).equals((otherTrioList.get(1)))) &&
					   ((trioList.get(0)).equals((otherTrioList.get(2))))){
				return true;
			}else if(((trioList.get(1)).equals((otherTrioList.get(0)))) &&
					   ((trioList.get(2)).equals((otherTrioList.get(1)))) &&
					   ((trioList.get(0)).equals((otherTrioList.get(2))))){
				return true;
			}else if(((trioList.get(2)).equals((otherTrioList.get(0)))) &&
					   ((trioList.get(1)).equals((otherTrioList.get(1)))) &&
					   ((trioList.get(0)).equals((otherTrioList.get(2))))){
				return true;
			}else if(((trioList.get(1)).equals((otherTrioList.get(0)))) &&
					   ((trioList.get(0)).equals((otherTrioList.get(1)))) &&
					   ((trioList.get(2)).equals((otherTrioList.get(2))))){
				return true;
			}else if(((trioList.get(0)).equals((otherTrioList.get(0)))) &&
					   ((trioList.get(2)).equals((otherTrioList.get(1)))) &&
					   ((trioList.get(1)).equals((otherTrioList.get(2))))){
				return true;
			}else if(((trioList.get(2)).equals((otherTrioList.get(0)))) &&
					   ((trioList.get(0)).equals((otherTrioList.get(1)))) &&
					   ((trioList.get(1)).equals((otherTrioList.get(2))))){
				return true;
			}else{
				return false;
			}		
		}
		return false;
	}

	/*******************************************************
	 * Extra Credit Portion: helper && compareTo method
	 *******************************************************/

	//Hint: make a private helper method to find the smallest item in any Trio.
	private Object helper(ArrayList<T> arrayListInput){
		if((arrayListInput.get(0).compareTo(arrayListInput.get(1)) < 1) &&
		   (arrayListInput.get(0).compareTo(arrayListInput.get(2)) < 1)){ 
			return arrayListInput.get(0);
		} else if((arrayListInput.get(1).compareTo(arrayListInput.get(0)) < 1) &&
			      (arrayListInput.get(1).compareTo(arrayListInput.get(2)) < 1)){
			return arrayListInput.get(1);	
	    } else if((arrayListInput.get(2).compareTo(arrayListInput.get(0)) < 1) &&
	    		  (arrayListInput.get(2).compareTo(arrayListInput.get(1)) < 1)){
	    	return arrayListInput.get(2);	
	    }
		return arrayListInput;
	}
	
	//returns a int value by comparing the smallest Value
	@Override
	public int compareTo(Trio<T> otherTrio) {
		ArrayList<T> othList = (ArrayList<T>) otherTrio.getList();
		Object smallestValue1 = helper(trioList); //gets the smallest value
		Object smallestValue2 = helper(othList);
		
		/*******************************************************
		 * >>if the smallest values are the same return 0
		 * >>if the smallest values are Strings return 1 or -1
		 * >>if the smallest values are Integer return 1 or -1
		 *******************************************************/
		if(smallestValue1.equals(smallestValue2) == true){
			return 0;
		}
		else if((smallestValue1 instanceof String) && (smallestValue2 instanceof String)){
			String otherStringValue = (String) smallestValue1; 
			String otherStringValue2 = (String) smallestValue2;
			if(otherStringValue.compareTo(otherStringValue2) < 1){
				return -1;
			}else if(otherStringValue.compareTo(otherStringValue2) > 1){
				return 1;	
			}
		}
		else if((smallestValue1 instanceof Integer) && (smallestValue2 instanceof Integer)){
			Integer otherIntegerValue = (Integer) smallestValue1;
			Integer otherIntegerValue2 = (Integer) smallestValue2;
			if(otherIntegerValue.compareTo(otherIntegerValue2) < 1){
				return -1;
			}else if(otherIntegerValue.compareTo(otherIntegerValue2) > 1){ 
				return 1;
			}
		}
		return 1;	
	}
}
